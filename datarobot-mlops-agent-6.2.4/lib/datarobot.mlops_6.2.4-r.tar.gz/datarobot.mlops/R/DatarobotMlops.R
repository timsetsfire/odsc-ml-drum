#' @docType package
#' @import jsonlite
#' @import digest
#' @import pack
#' @import tools
#' @importFrom utils tail file_test
"_PACKAGE"
