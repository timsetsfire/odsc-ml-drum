# Constants
LAST_RECORD_DELIMITER <- 0xFEEDCAFE
LAST_RECORD_DELIMITER_SIZE_BYTES <- 4
VERSION_AND_RECORD_LEN_SIZE_BYTES <- 4 * 3 + 8
MAGIC_NUMBER_RECORD <- 0xDEADBEEF
FS_SPOOLER_FILENAME <- "fs_spool."
FS_SPOOLER_VERSION <- 1

FSConfig <- new.env()

FSConfigClear <- function() {
    for (var in ls(FSConfig)) {
        rm(list = eval(var), envir = FSConfig)
    }
}

readSpoolDir <- function() {
    filenamePattern <- paste0(FS_SPOOLER_FILENAME, "*")
    Sys.glob(file.path(FSConfig$spoolDirectoryPath, filenamePattern))
}

getFilesTotalSize <- function(files_vec) {
    total_size <- 0
    for (filename in files_vec) {
        cur_size <- file.size(filename)
        if (!is.na(cur_size)) {
            total_size <- total_size + cur_size
        }
    }
    total_size
}

fileHasLastRecordDelimeter <- function(filepath) {
    if (file.size(filepath) < LAST_RECORD_DELIMITER_SIZE_BYTES) {
        return(FALSE)
    }

    f <- file(filepath, "rb")
    seek(f, -LAST_RECORD_DELIMITER_SIZE_BYTES, "end")
    x <- readBin(f, raw(), 4, 1)
    close(f)

    all(x == numToRawBigEndian(LAST_RECORD_DELIMITER))
}

closeCurrentAndRequestNewEnqueueFile <- function() {
    writeEndFileDelimeter <- function() {
        writeBin(numToRawBigEndian(LAST_RECORD_DELIMITER), FSConfig$currentEnqueueFile)
    }

    if (!is.null(FSConfig$currentEnqueueFile)) {
        writeEndFileDelimeter()
        close(FSConfig$currentEnqueueFile)
        FSConfig$currentEnqueueFile <- NULL
    }

    if (length(readSpoolDir()) >= FSConfig$spoolMaxFiles) {
        warning("Filesystem spooler reached max capacity:
        max files: ", FSConfig$spoolMaxFiles,"; max file size: ", FSConfig$spoolFileMaxSize)
        return(FALSE)
    }

    FSConfig$enqueueFileIndex <- FSConfig$enqueueFileIndex + 1
    new_enqueue_filepath <- file.path(
        FSConfig$spoolDirectoryPath,
        paste0(FS_SPOOLER_FILENAME, FSConfig$enqueueFileIndex)
    )

    FSConfig$currentEnqueueFile <- file(new_enqueue_filepath, "ab")
    FSConfig$currentEnqueueFileSize <- 0
    TRUE
}

checkSpoolerHasEnoughSpace <- function(bytes_to_write_size) {
    noRequiredSpace <- function(bytes_to_write_size) {
        required_size <- FSConfig$enqueueCurrentSize +
            bytes_to_write_size +
            LAST_RECORD_DELIMITER_SIZE_BYTES
        return(required_size > FSConfig$spoolCapacity)
    }

    if (noRequiredSpace(bytes_to_write_size)) {
            FSConfig$enqueueCurrentSize <- getFilesTotalSize(readSpoolDir())
            if (noRequiredSpace(bytes_to_write_size)) {
                warning("Filesystem spooler reached max capacity: \
                        max files: ", FSConfig$spoolMaxFiles,"; max file size: ", FSConfig$spoolFileMaxSize)
                return(FALSE)
            }
    }
    TRUE
}

initEnqueue <- function() {
    keyModificationTimeIndex <- function(files) {
        getSpoolFileIndex <- function(spool_filepath) {
            return(as.numeric(file_ext(basename(spool_filepath))))
        }

        modificationTimes <- vector()
        indexes <- vector()
        # from filenames create two vectors: modification time and index
        for (file_name in files) {
            modificationTimes <- append(modificationTimes, file.mtime(file_name))
            indexes <- append(indexes, getSpoolFileIndex(file_name))
        }
        return(list(modTime = modificationTimes, index = indexes))
    }

    spool_files_paths <- readSpoolDir()

    orderKeys <- keyModificationTimeIndex(spool_files_paths)
    # create an order, ordering modification times first and indexes
    ord <- order(orderKeys$modTime, orderKeys$index)
    spool_files_paths <- spool_files_paths[ord]
    if (length(spool_files_paths)) {
        FSConfig$enqueueCurrentSize <- getFilesTotalSize(spool_files_paths)
        enqueue_filepath <- tail(spool_files_paths, n = 1)
        # take the largest index of all spool files
        FSConfig$enqueueFileIndex <- max(orderKeys$index)
        if (!fileHasLastRecordDelimeter(enqueue_filepath)) {
            FSConfig$currentEnqueueFile <- file(enqueue_filepath, "ab")
            FSConfig$currentEnqueueFileSize <- file.size(enqueue_filepath)
        }
    }

    if (is.null(FSConfig$currentEnqueueFile)) {
        closeCurrentAndRequestNewEnqueueFile()
    }
}

FSSpoolerCreate <- function(spoolDirectoryPath, spoolFileMaxSize, spoolMaxFiles, addChecksum = TRUE) {
    FSConfigClear()
    FSConfig$spoolDirectoryPath <- spoolDirectoryPath
    FSConfig$spoolFileMaxSize <- spoolFileMaxSize
    FSConfig$spoolMaxFiles <- spoolMaxFiles
    FSConfig$spoolAddChecksum <- addChecksum

    FSConfig$spoolCapacity <- FSConfig$spoolFileMaxSize * FSConfig$spoolMaxFiles
    FSConfig$currentEnqueueFile <- NULL
    FSConfig$currentEnqueueFileSize <- 0

    # file index will be incremented and start with 1
    FSConfig$enqueueFileIndex <- 0
    FSConfig$enqueueCurrentSize <- 0

    if (!file.exists(FSConfig$spoolDirectoryPath)) {
        stop("Path: ", FSConfig$spoolDirectoryPath, " provided for spooler does not exist.")
    }

    if (!file_test("-d", FSConfig$spoolDirectoryPath)) {
        stop("Path: ", FSConfig$spoolDirectoryPath, " provided for spooler in not a directory.")
    }

    if (file.access(FSConfig$spoolDirectoryPath, 4) != 0) {
        stop("Path: ", FSConfig$spoolDirectoryPath, " provided for spooler does not have read permission.")
    }

    if (file.access(FSConfig$spoolDirectoryPath, 2) != 0) {
        stop("Path: ", FSConfig$spoolDirectoryPath, " provided for spooler does not have write permission.")
    }

    if (FSConfig$spoolFileMaxSize <= 0) {
        stop("Invalid value for spoolFileMaxSize: ", FSConfig$spoolFileMaxSize, ".")
    }

    if (FSConfig$spoolMaxFiles <= 0) {
        stop("Invalid value for spoolMaxFiles: ", FSConfig$spoolMaxFiles, ".")
    }
    initEnqueue()

    FSSpoolerEnqueue
}

FSSpoolerShutdown <- function() {
    shutdownEnqueue <- function() {
        if (!is.null(FSConfig$currentEnqueueFile)) {
            close(FSConfig$currentEnqueueFile)
            FSConfig$currentEnqueueFile <- NULL
        }
    }
    shutdownEnqueue()
}

numToRawBigEndian <- function(num, nBytes = 4) {
    # pack's numToRaw returns bytes in platform's defined order
    numRaw <- numToRaw(num, nBytes)
    if (.Platform$endian == "little") {
        numRaw <- rev(numRaw)
    }
    numRaw
}

FSSpoolerEnqueue <- function(record) {
    checkFileHasEnoughSpace <- function(bytes_to_write_size) {
        if (is.null(FSConfig$currentEnqueueFile))
            return(FALSE)
        if (FSConfig$currentEnqueueFileSize +
            bytes_to_write_size +
            LAST_RECORD_DELIMITER_SIZE_BYTES
            > FSConfig$spoolFileMaxSize)
                return(FALSE)
        return(TRUE)
    }

    recordSpoolerRawBuf <- function(record) {
        # serialize record into a bytearray
        recordRaw <- recordToRaw(record)

        checksumNum <- 0
        if (FSConfig$spoolAddChecksum) {
            checksum <- digest(recordRaw, "crc32", serialize = FALSE, raw = TRUE)
            # checksum is a string in a hex form 'deadbeef',
            # prepend it with 0x to convert to numeric
            checksumNum <- as.numeric(paste0("0x", checksum))
        }

        rawBuf <- c(
                    numToRawBigEndian(MAGIC_NUMBER_RECORD),
                    numToRawBigEndian(FS_SPOOLER_VERSION),
                    numToRawBigEndian(length(recordRaw)),
                    # spool reader expects checksum to be 8 bytes
                    numToRawBigEndian(checksumNum, 8),
                    recordRaw
        )
        return(rawBuf)
    }

    # write record to a file and update counters
    writeRecordBuf <- function(buf) {
        recordDumpSize <- length(buf)
        writeBin(buf, FSConfig$currentEnqueueFile)
        # TODO: if written data is buffered, spooler available space is calculated wrongly.
        # Consider fixing calculation in ..HasEnoughSpace functions or flush and fix tests.
        #flush(FSConfig$currentEnqueueFile)
        FSConfig$enqueueCurrentSize <- FSConfig$enqueueCurrentSize + recordDumpSize
        FSConfig$currentEnqueueFileSize <- FSConfig$currentEnqueueFileSize + recordDumpSize
    }

    spoolerBuf <- recordSpoolerRawBuf(record)
    recordDumpSize <- length(spoolerBuf)

    if (!checkSpoolerHasEnoughSpace(recordDumpSize)) {
        return(FALSE)
    }

    if (!checkFileHasEnoughSpace(recordDumpSize)) {
        if (!closeCurrentAndRequestNewEnqueueFile()) {
            return(FALSE)
        }
    }

    writeRecordBuf(spoolerBuf)
    TRUE
}
