# record is: list(deploymentId = deploymentId, dataFormat = dataFormat, dataType = dataType, payload = rawPayload)

recordToRaw <- function(record) {
    # Record structure:
    # < record_header_len, deployment_id_len, deployment_id,
    #   data_type, data_format, data_len, version, language_len, language, lib_version_len,
    #   lib_version, reserved_len, reserved, payload >

    mlopsRecordVersion <- 2
    language <- "R"
    languageRaw <- charToRaw(language)
    languageLen <- length(languageRaw)

    libVersion <- ""
    libVersionRaw <- charToRaw(libVersion)
    libVersionLen <- length(libVersionRaw)

    reserved <- ""
    reservedRaw <- charToRaw(reserved)
    reservedLen <- length(reservedRaw)

    deploymentRaw = charToRaw(record$deploymentId)
    deploymentIdLen <- length(deploymentRaw)
    # 5 => data_type, data_format, data_len, version, language_len
    recordHeaderLen <- 4 + deploymentIdLen + 5 * 4 + languageLen + 4 + libVersionLen + 4 + reservedLen

    payloadRaw <- charToRaw(record$payload)
    # serialize record into a bytearray
    c(
        numToRawBigEndian(recordHeaderLen),
        numToRawBigEndian(deploymentIdLen),
        deploymentRaw,
        numToRawBigEndian(record$dataType),
        numToRawBigEndian(record$dataFormat),
        numToRawBigEndian(length(payloadRaw)),
        numToRawBigEndian(mlopsRecordVersion),
        numToRawBigEndian(languageLen),
        languageRaw,
        numToRawBigEndian(libVersionLen),
        libVersionRaw,
        numToRawBigEndian(reservedLen),
        reservedRaw,
        payloadRaw
    )
}