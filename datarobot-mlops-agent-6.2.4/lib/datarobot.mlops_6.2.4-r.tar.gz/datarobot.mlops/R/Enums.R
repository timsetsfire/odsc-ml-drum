OutputType <- list(STDOUT = "STDOUT",
                   FILESYSTEM = "FILESYSTEM",
                   NONE = "NONE",
                   INVALID = "INVALID")

DataFormat <- list(BYTE_ARRAY = 0, JSON = 1, INVALID = 2)

DataType <- list(INVALID = 0,
                 FEATURE_DRIFT = 1,
                 TARGET_DRIFT = 2,
                 DEPLOYMENT_STATS = 3,
                 FEATURE_DATA = 4,
                 PREDICTIONS_STATS_SC_CLASSIFICATION = 5,
                 PREDICTIONS_STATS_SC_REGRESSION = 6,
                 PREDICTIONS_DATA = 7
                 )
