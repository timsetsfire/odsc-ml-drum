getStdoutChannelSubmitter <- function() {
    function(record) {
        print(">>> Record Start >>>")
        print(record)
        print("<<< Record End <<<")
        TRUE
    }
}

getSpoolerChannelSubmitter <- function() {
    FSSpoolerCreate(getSpoolerDir(),
                    getSpoolerFileMaxSize(),
                    getSpoolerMaxFiles(),
                    getConfigDefault(ConfigConstants$SPOOLER_CHECKSUM, TRUE))
}
