MLOpsConfig <- new.env()

MLOpsConfigClear <- function() {
    for (var in ls(MLOpsConfig)) {
        rm(list = eval(var), envir = MLOpsConfig)
    }
}

MLOpsConfig$OutputChannelSubmit <- NULL
MLOpsConfig$MLOpsInitialized <- FALSE

#' Initialize MLOps
#'
#' MLOps initialization.
#'
#' @param deploymentId character. The ID of a deployment.
#' @param modelId character. The ID of a model.
#' @param outputType character. Can be "FILESYSTEM", "STDOUT" or "NULL".
#' @param spoolerDir character. A directory for spool files.
#' @param spoolerFileMaxSize numeric. Maximum allowed size of a spool file.
#' @param spoolerMaxFiles numeric. Maximum allowed number of spool files.
#' @param spoolerChecksum logical. Either add checksum for each record.
#' @examples
#' \dontrun{
#' # Function parameters can be defined in environment variables or explicitly passed.
#' # export MLOPS_DEPLOYMENT_ID=1234
#' # export MLOPS_MODEL_ID=4567
#' # export MLOPS_SPOOLER_TYPE=FILESYSTEM
#' # export MLOPS_FILESYSTEM_DIRECTORY=/tmp/somedir
#' # export MLOPS_FILESYSTEM_MAX_FILE_SIZE=104857600
#' # export MLOPS_FILESYSTEM_MAX_NUM_FILES=5
#'
#' MLOpsInit()
#'
#' # Parameters defined in the environment variables take precedence over the ones explicitly provided.
#' MLOpsInit(deploymentId = "1234", modelId = "4567", outputType = "FILESYSTEM",
#' spoolerDir = "/tmp/somedir", spoolerFileMaxSize = 104857600, spoolerMaxFiles = 5)
#' }
#' @export
MLOpsInit <- function (deploymentId = NULL, modelId = NULL, outputType = NULL,
                       spoolerDir = NULL, spoolerFileMaxSize = NULL, spoolerMaxFiles = NULL,
                       spoolerChecksum = NULL) {
    ConfigEnvClear()

    if (!is.null(deploymentId)) {setDeploymentId(deploymentId)}
    if (!is.null(modelId)) {setModelId(modelId)}
    if (!is.null(outputType)) {setOutputType(outputType)}
    if (!is.null(spoolerDir)) {setSpoolerDir(spoolerDir)}
    if (!is.null(spoolerFileMaxSize)) {setSpoolerFileMaxSize(spoolerFileMaxSize)}
    if (!is.null(spoolerMaxFiles)) {setSpoolerMaxFiles(spoolerMaxFiles)}
    if (!is.null(spoolerChecksum)) {setConfig(ConfigConstants$SPOOLER_CHECKSUM, spoolerChecksum)}

    if (!MLOpsConfig$MLOpsInitialized) {
        outputType <- getOutputType()
        if (outputType == OutputType$STDOUT) {
            MLOpsConfig$OutputChannelSubmit <- getStdoutChannelSubmitter()
        } else if (outputType == OutputType$FILESYSTEM) {
            MLOpsConfig$OutputChannelSubmit <- getSpoolerChannelSubmitter()
        } else {
            warning("Output channel is: NULL")
        }
        MLOpsConfig$MLOpsInitialized <- TRUE
    }
    invisible(NULL)
}

#' MLOps Shutdown
#'
#' Gracefully shutdown MLOps.
#' @examples
#' MLOpsShutdown()
#' @export
MLOpsShutdown <- function() {
    if (MLOpsConfig$MLOpsInitialized) {
        FSSpoolerShutdown()
        MLOpsConfigClear()
    }
    MLOpsConfig$MLOpsInitialized <- FALSE
    invisible(NULL)
}

validateMLOps <- function() {
    if (!MLOpsConfig$MLOpsInitialized) {
        stop("MLOps is not initialized")
    }
}

#' Report deployment statistics to DataRobot MLOps.
#'
#' @param numPredictions integer. Number of predictions.
#' @param executionTimeMs double. Predictions execution time ms.
#' @return success status TRUE/FALSE
#' @examples
#' \dontrun{
#' # In a real example, predictionsDataFrame would be result of scoring.
#' time.start <- Sys.time()
#' predictionsDataFrame <- data.frame(Yes = c(0.1, 0.2), No = c(0.9, 0.8))
#' time.finish <- Sys.time()
#' time.takenMsec <- as.double((time.finish - time.start) * 1000)
#' MLOpsReportDeploymentStats(nrows(predictionsDataFrame), time.takenMsec)
#' }
#' @export
MLOpsReportDeploymentStats <- function(numPredictions, executionTimeMs) {
    validateMLOps()
    if (is.null(MLOpsConfig$OutputChannelSubmit)) return(FALSE)

    generalStats <- GeneralStats()
    deploymentStats <- DeploymentStats(numPredictions, executionTimeMs)
    payloadJson <- DeploymentStatsSerialize(generalStats, deploymentStats)

    record <- list(deploymentId = getDeploymentId(),
                   dataFormat = DataFormat$BYTE_ARRAY,
                   dataType = DataType$DEPLOYMENT_STATS,
                   payload = payloadJson)
    MLOpsConfig$OutputChannelSubmit(record)
    return(TRUE)
}

#' Report predictions data to DataRobot MLOps.
#'
#' @param features list/dataframe. A dictionary of values for each feature.
#' @param predictions vector. Regression or classification predictions to report.
#' @param associationIds list. List of association IDs corresponding to each
#'   prediction. Used for accuracy calculations. Optional.
#' @param classNames list. Feature class names.
#' @return success status TRUE/FALSE
#' @examples
#' \dontrun{
#' # In a real example features would be the samples dataset to do predictions on and predictions
#' will be the actual prediction values.  associationIds are the random but unique strings
#' corresponding to each prediction value
#' features <- data.frame(feature1 = c(0.3, 0.4, 0.6), feature2 = c("aa", "bb", "cc"))
#' predictions <- list(list(0.1, 0.9), list(0.2, 0.8))
#' classNames <- c("c1", "c2")
#' associationIds <- c("x", "y")
#' MLOpsReportPredictionsData(features, predictions, associationIds, classNames)
#' }
#' @export
MLOpsReportPredictionsData <- function(features = NULL, predictions = NULL, associationIds = NULL, classNames = NULL) {
    validateMLOps()
    if (is.null(MLOpsConfig$OutputChannelSubmit)) return(FALSE)

    generalStats <- GeneralStats()
    predictionsData <- PredictionsData(features, predictions, associationIds, classNames)
    payloadJson <- PredictionsDataSerialize(generalStats, predictionsData)
    record <- list(deploymentId = getDeploymentId(),
                   dataFormat = DataFormat$BYTE_ARRAY,
                   dataType = DataType$PREDICTIONS_DATA,
                   payload = payloadJson)
    MLOpsConfig$OutputChannelSubmit(record)
    return(TRUE)
}
