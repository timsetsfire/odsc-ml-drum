ConfigEnv <- new.env()

ConfigEnvClear <- function() {
    for (var in ls(ConfigEnv)) {
        rm(list = eval(var), envir = ConfigEnv)
    }
}

# set key-value to config env
setConfig <- function(configConstant, value) {
    assign(configConstant$key, value, envir = ConfigEnv)
}

# get value from config env or from sys env
getConfig <- function(configConstant) {
    key <- configConstant$key
    coerceMethod <- configConstant$coercion

    sysEnvValue <- Sys.getenv(key)
    if (sysEnvValue != "") {
        return(coerceMethod(sysEnvValue))
    }

    if (exists(key, envir = ConfigEnv)) {
        return(get(key, envir = ConfigEnv))
    }

    stop("Config parameter: ", key, " is not defined")
}

# try to get value, return default if not found
getConfigDefault <- function(configConstant, default) {
    tryCatch(
        {
            getConfig(configConstant)
        },
        error = function(cond) {
            default
        }
    )
}

# closure to define setter methods
createSetter <- function(configConstant) {
    function(configValue) {
        setConfig(configConstant, configValue)
    }
}

# closure to define getter methods
createGetter <- function(configConstant) {
    function() {
        getConfig(configConstant)
    }
}

setDeploymentId <- createSetter(ConfigConstants$DEPLOYMENT_ID)
getDeploymentId <- createGetter(ConfigConstants$DEPLOYMENT_ID)

setModelId <- createSetter(ConfigConstants$MODEL_ID)
getModelId <- createGetter(ConfigConstants$MODEL_ID)

setOutputType <- createSetter(ConfigConstants$SPOOLER_TYPE)
getOutputType <- createGetter(ConfigConstants$SPOOLER_TYPE)

setSpoolerDir <- createSetter(ConfigConstants$FILESYSTEM_DIRECTORY)
getSpoolerDir <- createGetter(ConfigConstants$FILESYSTEM_DIRECTORY)

setSpoolerFileMaxSize <- createSetter(ConfigConstants$FILESYSTEM_MAX_FILE_SIZE)
getSpoolerFileMaxSize <- createGetter(ConfigConstants$FILESYSTEM_MAX_FILE_SIZE)

setSpoolerMaxFiles <- createSetter(ConfigConstants$FILESYSTEM_MAX_NUM_FILES)
getSpoolerMaxFiles <- createGetter(ConfigConstants$FILESYSTEM_MAX_NUM_FILES)
