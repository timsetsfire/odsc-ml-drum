ConfigConstants <- new.env()

createConstant <- function(key, coercion) {
    list(key = key, coercion = coercion)
}

ConfigConstants$DEPLOYMENT_ID <- createConstant("MLOPS_DEPLOYMENT_ID", as.character)
ConfigConstants$MODEL_ID <- createConstant("MLOPS_MODEL_ID", as.character)
ConfigConstants$FILESYSTEM_DIRECTORY <- createConstant("MLOPS_FILESYSTEM_DIRECTORY", as.character)
ConfigConstants$FILESYSTEM_MAX_FILE_SIZE <- createConstant("MLOPS_FILESYSTEM_MAX_FILE_SIZE", as.numeric)
ConfigConstants$FILESYSTEM_MAX_NUM_FILES <- createConstant("MLOPS_FILESYSTEM_MAX_NUM_FILES", as.numeric)
ConfigConstants$SPOOLER_CHECKSUM <- createConstant("MLOPS_SPOOLER_CHECKSUM", as.logical)
ConfigConstants$SPOOLER_TYPE <- createConstant("MLOPS_SPOOLER_TYPE", as.character)
ConfigConstants$ASYNC_REPORTING <- createConstant("MLOPS_ASYNC_REPORTING", as.logical)
ConfigConstants$REPORT_QUEUE_NUM_LISTS <- createConstant("MLOPS_REPORT_QUEUE_NUM_LISTS", as.integer)
ConfigConstants$REPORT_QUEUE_LIST_SIZE <- createConstant("MLOPS_REPORT_QUEUE_LIST_SIZE", as.integer)

lockBinding("DEPLOYMENT_ID", ConfigConstants)
lockBinding("MODEL_ID", ConfigConstants)
lockBinding("FILESYSTEM_DIRECTORY", ConfigConstants)
lockBinding("FILESYSTEM_MAX_FILE_SIZE", ConfigConstants)
lockBinding("FILESYSTEM_MAX_NUM_FILES", ConfigConstants)
lockBinding("SPOOLER_CHECKSUM", ConfigConstants)
lockBinding("SPOOLER_TYPE", ConfigConstants)
lockBinding("ASYNC_REPORTING", ConfigConstants)
lockBinding("REPORT_QUEUE_NUM_LISTS", ConfigConstants)
lockBinding("REPORT_QUEUE_LIST_SIZE", ConfigConstants)