GeneralStats <- function() {
    list(modelId = getModelId(), timestamp = strftime(Sys.time(), format="%Y-%m-%d %H:%M:%OS3%z"))
}

DeploymentStats <- function(num_predictions, execution_time) {
    list(numPredictions = num_predictions, executionTime = execution_time)
}

DeploymentStatsSerialize <- function(generalStats, deploymentsStats) {
    js <- toJSON(c(generalStats, deploymentsStats), auto_unbox = TRUE)
}

PredictionStats <- function(predictions, classNames, associationIds) {
    numPredictions <- length(predictions)
    # class_names should be a list (other types?)
    # predictions can be list, list of lists, dataframe.
    if (is.data.frame(predictions)) {
        # unname df so it will be coverted to a list of lists by rows
        numPredictions <- nrow(predictions)
        predictions <- unname(predictions)
        #predictions <- do.call(function(...) Map(list, ...), unname(predictions))
    }
    if (!is.null(associationIds)) {
        if (numPredictions != length(associationIds)) {
            stop("Number of predictions: ", numPredictions,
                  " isn't equal to the number of accosiation IDs: ", length(associationIds))
        }

        if (length(associationIds) != length(unique(associationIds))) {
            stop("Association IDs vector has contain unique values")
        }
    }
    list(predictions = predictions, classNames = classNames, associationIds = associationIds)
}

PredictionStatsSerialize <- function(generalStats, predictionStats) {
    results_obj <- list(timestamp = generalStats$timestamp,
                        modelId = generalStats$modelId,
                        predictions = predictionStats$predictions)

    if (!is.null(predictionStats$associationIds)) {
        results_obj <- c(results_obj, list(associationIds = predictionStats$associationIds))
    }

    ret_object = list(results = list(results_obj))
    if (!is.null(predictionStats$classNames)) {
        ret_object <- c(ret_object, list(classNames = predictionStats$classNames))
    }
    js <- toJSON(ret_object, auto_unbox = TRUE)
}

FeatureDataStats <- function(featureData) {
    # featureData list of lists, dataframe.
    if (is.data.frame(featureData)) {
        # covert df to a list of lists by columns
        featureData <- as.list(featureData)
    }
    list(featureData = featureData)
}

FeatureDataStatsSerialize <- function(featureDataStats) {
    js <- toJSON(featureDataStats$featureData, auto_unbox = TRUE)
}

PredictionsData <- function(featureData, predictions, associationIds, classNames) {
    numFeatureValues <- 0
    if (!is.null(featureData)) {
        # featureData list of lists, dataframe.
        if (is.data.frame(featureData)) {
            # covert df to a list of lists by columns
            featureData <- as.list(featureData)
        }
        # Get the length of the first list
        numFeatureValues = length(featureData[[1]])
    }

    numPredictions <- 0
    if (!is.null(predictions)) {
        numPredictions <- length(predictions)
        # class_names should be a list (other types?)
        # predictions can be list, list of lists, dataframe.
        if (is.data.frame(predictions)) {
            # unname df so it will be coverted to a list of lists by rows
            numPredictions <- nrow(predictions)
            predictions <- do.call(function(...) Map(list, ...), unname(predictions))
        }
        if (!is.null(associationIds)) {
            if (numPredictions != length(associationIds)) {
                stop("Number of predictions: ", numPredictions,
                      " isn't equal to the number of accosiation IDs: ", length(associationIds))
            }

            if (length(associationIds) != length(unique(associationIds))) {
                stop("Association IDs vector has contain unique values")
            }
        }
        isClassficationPrediction <- is.list(predictions[[1]])
        is.scalar <- function(x) is.atomic(x) && length(x) == 1L
        for (prediction in predictions) {
            if (isClassficationPrediction && !is.list(prediction)) {
                stop("Expecting list of prediction probabilities, got scalar: ", prediction)
            }
            if (!isClassficationPrediction && !is.scalar(prediction)) {
                stop("Expecting scalar prediction value, got non-scalar: ", prediction)
            }
        }

        if (!is.null(classNames) && isClassficationPrediction) {
            numClassNames <- length(classNames)
            for (prediction in predictions) {
                if (numClassNames != length(prediction)) {
                    stop("Number of class names: ", numClassNames,
                        " differ from number of prediction probabilities: ", prediction)
                }
            }
        }
    }

    if (numFeatureValues == 0 && numPredictions == 0) {
        stop("Missing both 'features' and 'predictions', at least one is required")
    }

    if (numFeatureValues > 0 && numPredictions > 0 && numFeatureValues != numPredictions) {
        stop("Number of feature rows: ", numFeatureValues,
            " isn't equal to the number of predictions: ", numPredictions)
    }

    list(features = featureData, predictions = predictions, associationIds = associationIds, classNames = classNames)
}

PredictionsDataSerialize <- function(generalStats, predictionsData) {
    predictionsDataObj <- list(timestamp = generalStats$timestamp,
                        modelId = generalStats$modelId)

    if (!is.null(predictionsData$features)) {
        predictionsDataObj <- c(predictionsDataObj, list(features = predictionsData$features))
    }
    if (!is.null(predictionsData$predictions)) {
        predictionsDataObj <- c(predictionsDataObj, list(predictions = predictionsData$predictions))
    }
    if (!is.null(predictionsData$associationIds)) {
        predictionsDataObj <- c(predictionsDataObj, list(associationIds = predictionsData$associationIds))
    }
    if (!is.null(predictionsData$classNames)) {
        predictionsDataObj <- c(predictionsDataObj, list(classNames = predictionsData$classNames))
    }
    js <- toJSON(predictionsDataObj, auto_unbox = TRUE)
}