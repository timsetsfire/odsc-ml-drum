context("Test MLOps")

getFirstChecksum <- function(spoolerDir) {
    spoolFile <- file.path(spoolerDir, paste0(FS_SPOOLER_FILENAME, "1"))
    f <- file(spoolFile, "rb")
    seek(f, 12)
    rawChecksum <- readBin(f, raw(), 8, 1)
    close(f)
    return(rawChecksum)
}

test_that("MLOps init/shutdown works", {
    expect_error(MLOpsReportDeploymentStats(1, 2), "MLOps is not initialized")
    MLOpsInit(deploymentId = "test_deployment_id", modelId = "test_model_id", outputType = "STDOUT")
    MLOpsReportDeploymentStats(1000, 3)
    MLOpsShutdown()

    expect_error(MLOpsReportDeploymentStats(1, 2), "MLOps is not initialized")
})

test_that("MLOps null spooler channel works", {
    MLOpsInit(deploymentId = "test_deployment_id", modelId = "test_model_id", outputType = "NULL")
    expect_error(MLOpsReportDeploymentStats(1000, 3), NA)
    MLOpsShutdown()
})

test_that("MLOps stats reporting works", {
    MLOpsInit(deploymentId = "test_deployment_id", modelId = "test_model_id", outputType = "STDOUT")

    MLOpsReportDeploymentStats(1000, 3)

    predictionsList <- list(list(0.1, 0.2, 0.7), list(0.2, 0.3, 0.5))
    predictionsDataframe <- data.frame(class1 = c(0.1, 0.2), class2 = c(0.2, 0.3), class3 = c(0.7, 0.5))
    classNames <- c("class1", "class2", "class3")
    associationIds <- c("id1", "id2")

    MLOpsReportPredictionsData(predictions = predictionsList, classNames = classNames, associationIds = associationIds)
    MLOpsReportPredictionsData(predictions = predictionsDataframe, classNames = classNames, associationIds = associationIds)

    expect_error(MLOpsReportPredictionsData(predictions = predictionsDataframe, classNames = classNames, associationIds = c("id1", "id2", "id3")))
    expect_error(MLOpsReportPredictionsData(predictions = predictionsDataframe, classNames = classNames, associationIds = c("id2", "id2")))

    MLOpsReportPredictionsData(predictions = c(0.3, 0.4, 0.5))

    MLOpsReportPredictionsData(features = list(feature1 = c(0.3, 0.4, 0.5), feature2 = c("aa", "bb", "cc")))
    featuresDataframe <- data.frame(feature1 = c(0.3, 0.4, 0.6), feature2 = c("aa", "bb", "cc"))
    MLOpsReportPredictionsData(features = featuresDataframe)
    MLOpsShutdown()
    expect_true(TRUE)
})

test_that("MLOps prediction data reporting works", {
    MLOpsInit(deploymentId = "test_deployment_id", modelId = "test_model_id", outputType = "STDOUT")

    features <- list(feature1 = c(0.3, 0.4), feature2 = c("aa", "bb"))
    binaryPredictions <- list(list(0.1, 0.9), list(0.2, 0.8))
    classNames <- c("c1", "c2")
    associationIds <- c("x", "y")

    # Report Binary predictions with features as list of lists
    MLOpsReportPredictionsData(features, binaryPredictions, associationIds, classNames)

    # Report regression predictions
    regressionPredictions <- list(12, 13)
    MLOpsReportPredictionsData(features, regressionPredictions, associationIds)

    # Report features through data frame
    featuresDataframe <- data.frame(feature1 = c(0.3, 0.4), feature2 = c("aa", "bb"))
    MLOpsReportPredictionsData(featuresDataframe, binaryPredictions, associationIds, classNames)

    # Number of feature rows not equal to number of predictions
    featuresDataframe <- data.frame(feature1 = c(0.3, 0.4, 0.5), feature2 = c("aa", "bb", "cc"))
    expect_error(MLOpsReportPredictionsData(featuresDataframe, binaryPredictions, associationIds))

    # Number of predictions not equal to number of association associationIds
    badAssociationIds <- c("x", "y", "z")
    expect_error(MLOpsReportPredictionsData(features, binaryPredictions, badAssociationIds))

    # Non-unique association ids
    nonUniqueAssociationIds <- c("x", "x")
    expect_error(MLOpsReportPredictionsData(features, binaryPredictions, nonUniqueAssociationIds))

    # Regression prediction in classification predictions
    badClassificationPredictions <- list(list(0.1, 0.9), 14)
    expect_error(MLOpsReportPredictionsData(features, badClassificationPredictions, associationIds))

    # Classification prediction in regression predictions
    badRegressionPredictions <- list(12, list(0.1, 0.9))
    expect_error(MLOpsReportPredictionsData(features, badRegressionPredictions, associationIds))

    # Class names length different than prediction length
    badClassNames <- c("c1", "c2", "c3")
    expect_error(MLOpsReportPredictionsData(features, binaryPredictions, classNames = badClassNames))

    # Post only features
    MLOpsReportPredictionsData(features)

    # Post only predictions
    MLOpsReportPredictionsData(predictions = binaryPredictions)
    MLOpsReportPredictionsData(predictions = regressionPredictions)

    # Post features and predictions
    MLOpsReportPredictionsData(features = features, predictions = binaryPredictions)
    MLOpsReportPredictionsData(features = features, predictions = regressionPredictions)

    # Post predictions and associationIds
    MLOpsReportPredictionsData(predictions = binaryPredictions, associationIds = associationIds)
    MLOpsReportPredictionsData(predictions = regressionPredictions, associationIds = associationIds)

    # Error if no features and predictions are posted
    expect_error(MLOpsReportPredictionsData(associationIds = associationIds))

    # Predictions with dataframe
    predictionsDataframe <- data.frame(class1 = c(0.1, 0.2), class2 = c(0.2, 0.3))
    MLOpsReportPredictionsData(predictions = predictionsDataframe)

    MLOpsShutdown()
    expect_true(TRUE)
})

test_that("Spooler checksum enabled", {
    tryCatch(
    {
        tmpDir <- tempfile(pattern = "file", tmpdir = tempdir(), fileext = "")
        dir.create(tmpDir, recursive = TRUE)

        Sys.setenv(MLOPS_SPOOLER_CHECKSUM = "true")

        MLOpsInit(deploymentId = "1234", modelId = "4567", outputType = "FILESYSTEM",
                  spoolerDir = tmpDir, spoolerFileMaxSize = 1024, spoolerMaxFiles = 5)
        for (i in 1:10) {
            MLOpsReportDeploymentStats(1000, 3)
        }
        MLOpsShutdown()

        expect_false(all(getFirstChecksum(tmpDir) == numToRawBigEndian(0, 8)))
    },
    finally = {
        unlink(tmpDir, recursive = TRUE)
        Sys.unsetenv("MLOPS_SPOOLER_CHECKSUM")
    })
})

test_that("Spooler checksum disabled", {
    tryCatch(
    {
        tmpDir <- tempfile(pattern = "file", tmpdir = tempdir(), fileext = "")
        dir.create(tmpDir, recursive = TRUE)

        Sys.setenv(MLOPS_SPOOLER_CHECKSUM = "false",
                   MLOPS_DEPLOYMENT_ID = "1234",
                   MLOPS_MODEL_ID = "5678",
                   MLOPS_FILESYSTEM_DIRECTORY = tmpDir,
                   MLOPS_SPOOLER_TYPE = "FILESYSTEM",
                   MLOPS_FILESYSTEM_MAX_FILE_SIZE = 1024,
                   MLOPS_FILESYSTEM_MAX_NUM_FILES = 5
        )

        MLOpsInit()
        for (i in 1:10) {
            MLOpsReportDeploymentStats(1000, 3)
        }
        MLOpsShutdown()
        expect_true(all(getFirstChecksum(tmpDir) == numToRawBigEndian(0, 8)))
    },
    finally = {
        unlink(tmpDir, recursive = TRUE)
        Sys.unsetenv(c("MLOPS_SPOOLER_CHECKSUM", "MLOPS_DEPLOYMENT_ID", "MLOPS_MODEL_ID",
        "MLOPS_FILESYSTEM_DIRECTORY", "MLOPS_SPOOLER_TYPE", "MLOPS_FILESYSTEM_MAX_FILE_SIZE",
        "MLOPS_FILESYSTEM_MAX_NUM_FILES"))
    })
})
