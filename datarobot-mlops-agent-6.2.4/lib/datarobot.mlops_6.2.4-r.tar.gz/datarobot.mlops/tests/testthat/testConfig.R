context("Test Config")

test_that("set/get config", {
    ConfigEnvClear()
    Sys.unsetenv("MLOPS_DEPLOYMENT_ID")
    expect_error(getDeploymentId(), "Config parameter: MLOPS_DEPLOYMENT_ID is not defined")

    deployment_id <- "test_deployment_id"
    model_id <- "test_model_id"

    setDeploymentId(deployment_id)
    expect_equal(deployment_id, getDeploymentId())

    setModelId(model_id)
    expect_equal(model_id, getModelId())

    setOutputType(OutputType$STDOUT)
    expect_equal(OutputType$STDOUT, getOutputType())

    expect_true(getConfigDefault(ConfigConstants$SPOOLER_CHECKSUM, TRUE))
})