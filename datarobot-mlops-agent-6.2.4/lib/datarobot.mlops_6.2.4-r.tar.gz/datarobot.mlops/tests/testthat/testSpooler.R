context("Test Spooler")

createTestRecord <- function() {
    data <- list(field1 = paste0(rep("1", 46), collapse = ""))
    record <- list(deploymentId = "deployment_id",
                   dataFormat = DataFormat$BYTE_ARRAY,
                   dataType = DataType$DEPLOYMENT_STATS,
                   payload = toJSON(data, auto_unbox = TRUE))
}

getSpoolFileSize <- function(record) {
    expectedRecordsPerFile <- 3
    rawRecord <- recordToRaw(record)
    recordLen <- length(rawRecord) + VERSION_AND_RECORD_LEN_SIZE_BYTES
    expectedRecordsPerFile * recordLen + LAST_RECORD_DELIMITER_SIZE_BYTES
}

test_that("Spooler general cases", {
    tryCatch(
    {
        tmpDir = tempfile(pattern = "file", tmpdir = tempdir(), fileext = "")
        dir.create(tmpDir, recursive = TRUE)

        record <- createTestRecord()
        SpoolerEnqueue <- FSSpoolerCreate(tmpDir, getSpoolFileSize(record) + 1, 5)

        for (i in 1:13) {
            expect_true(SpoolerEnqueue(record))
        }

        for (i in c("1", "2", "3", "4")) {
            filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, i))
            expect_true(file.exists(filepath))
            expect_true(fileHasLastRecordDelimeter(filepath))
        }

        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "5"))
        expect_true(file.exists(filepath))
        expect_false(fileHasLastRecordDelimeter(filepath))

        for (i in c("1", "2", "3")) {
            filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, i))
            unlink(filepath)
        }

        for (i in 1:10) {
            expect_true(SpoolerEnqueue(record))
        }

        for (i in c("4", "5", "6", "7")) {
            filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, i))
            expect_true(file.exists(filepath))
            expect_true(fileHasLastRecordDelimeter(filepath))
        }

        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "8"))
        expect_true(file.exists(filepath))
        expect_false(fileHasLastRecordDelimeter(filepath))

        FSSpoolerShutdown()
    },
    finally = {
        unlink(tmpDir, recursive = TRUE)
    })
})

test_that("Spooler does not have enough space", {
    tryCatch(
    {
        tmpDir = tempfile(pattern = "file", tmpdir = tempdir(), fileext = "")
        dir.create(tmpDir, recursive = TRUE)

        record <- createTestRecord()
        SpoolerEnqueue <- FSSpoolerCreate(tmpDir, getSpoolFileSize(record) + 1, 5)

        for (i in 1:15) {
            expect_true(SpoolerEnqueue(record))
        }

        expect_false(SpoolerEnqueue(record))
        for (i in c("1", "2", "3", "4", "5")) {
            filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, i))
            expect_true(file.exists(filepath))
            expect_true(fileHasLastRecordDelimeter(filepath))
        }
        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "6"))
        expect_false(file.exists(filepath))
        FSSpoolerShutdown()
    },
    finally = {
        unlink(tmpDir, recursive = TRUE)
    })
})

test_that("Spooler gets restarted", {
    tryCatch(
    {
        tmpDir = tempfile(pattern = "file", tmpdir = tempdir(), fileext = "")
        dir.create(tmpDir, recursive = TRUE)

        record <- createTestRecord()
        SpoolerEnqueue <- FSSpoolerCreate(tmpDir, getSpoolFileSize(record) + 1, 5)

        for (i in 1:4) {
            expect_true(SpoolerEnqueue(record))
        }

        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "1"))
        expect_true(file.exists(filepath))
        expect_true(fileHasLastRecordDelimeter(filepath))

        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "2"))
        expect_true(file.exists(filepath))
        expect_false(fileHasLastRecordDelimeter(filepath))

        FSSpoolerShutdown()

        SpoolerEnqueue <- FSSpoolerCreate(tmpDir, getSpoolFileSize(record) + 1, 5)

        for (i in seq(1:4)) {
            expect_true(SpoolerEnqueue(record))
        }

        for (i in c("1", "2")) {
            filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, i))
            expect_true(file.exists(filepath))
            expect_true(fileHasLastRecordDelimeter(filepath))
        }

        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "3"))
        expect_true(file.exists(filepath))
        expect_false(fileHasLastRecordDelimeter(filepath))

        filepath <- file.path(tmpDir, paste0(FS_SPOOLER_FILENAME, "4"))
        expect_false(file.exists(filepath))

        FSSpoolerShutdown()
    },
    finally = {
        unlink(tmpDir, recursive = TRUE)
    })
})
